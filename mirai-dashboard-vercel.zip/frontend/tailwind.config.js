/** @type {import('tailwindcss').Config} */
export default {
  content: [\n    "./index.html",\n    "./src/**/*.{js,ts,jsx,tsx}",\n  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

